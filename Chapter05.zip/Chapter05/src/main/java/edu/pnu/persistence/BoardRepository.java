package edu.pnu.persistence;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.pnu.domain.Board;

public interface BoardRepository extends JpaRepository<Board, Long> {
	List<Board> findByTitleLike(String keyword, Pageable paging);
	
	@Query("Select b from Board b where b.title like %1% order by b.seq desc")
	List<Board> queryAnnotationTest1(String searchKeyword);
	
	
}
