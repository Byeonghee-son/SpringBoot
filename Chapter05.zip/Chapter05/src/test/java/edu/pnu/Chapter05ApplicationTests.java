package edu.pnu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
